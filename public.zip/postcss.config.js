// module.exports = {
//     plugins: [
//       require('postcss-prefixer')({
//         prefix: '.ai-soc', // 自定义的前缀
//         transform: (prefix, selector, prefixedSelector) => {
//           // 只替换以 .ant- 开头的选择器
//           if (selector.startsWith('.ant-')) {
//             return selector.replace('.ant-', '.ai-soc-');
//           }
//           return selector;
//         }
//       })
//     ]
//   };
  